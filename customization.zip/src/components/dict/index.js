import T from './JDictSelectTag.vue'
const JDictSelectTag = {
  install: function (Vue) {
    Vue.component('JDictSelectTag',T);
  }
}
export default JDictSelectTag;