<template>
      <div id="doct1">
            <span class="circle"></span>
      </div>
</template>
<script>
export default {
      
}
</script>
<style lang="less" scoped>
#doct1{
      width: 20px;
      height: 20px;
      border: 1px solid #33b8b3;
      border-radius: 10px;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 10px;
      .circle{
            width: 14px;
            height: 14px;
            background-color: #33b8b3;
            border-radius: 7px;
      }

}
</style>
