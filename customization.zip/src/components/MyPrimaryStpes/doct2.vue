<template>
      <div id="primary-doct2">
            <a-icon type="check" />
      </div>
</template>
<style lang="less" scoped>
#primary-doct2{
      width: 26px;
      height: 26px;
      background-color: #33b8b3;
      border-radius: 13px;
      display: flex;
      align-items: center;
      justify-items: center;
      text-align: center;
      padding-left: 5px;
      margin-top: 10px;
      i{
            color: #fff;
      }
}
</style>
