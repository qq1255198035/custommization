<template>
      <div id="btn">
            <a-button>
                  <slot></slot>
            </a-button>
      </div>      
</template>
<script>
export default {
      
}
</script>
<style lang="less" scoped>

</style>
