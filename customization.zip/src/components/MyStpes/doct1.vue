<template>
      <div id="doct1">
            <span class="circle"></span>
      </div>
</template>
<script>
export default {
      
}
</script>
<style lang="less" scoped>
#doct1{
      width: 20px;
      height: 20px;
      border: 1px solid #fff;
      border-radius: 10px;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 10px;
      .circle{
            width: 14px;
            height: 14px;
            background-color: #fff;
            border-radius: 7px;
      }

}
@media screen and (max-width: 768px) and (min-width: 325px){
      #doct1{
            width: 14px;
            height: 14px;
            .circle{
                  width: 10px;
                  height: 10px;
            }
      }
}
</style>
