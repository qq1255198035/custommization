<template>
    <div class="right">
        <ul>
            <li><a-icon type="bell" /></li>
            <li><a-icon type="user" /></li>
        </ul>
    </div>
</template>

<script>
export default {
    props: {

    },
    data() {
        return {

        };
    },
    computed: {

    },
    created() {

    },
    mounted() {

    },
    watch: {

    },
    methods: {

    },
    components: {

    },
};
</script>

<style scoped lang="less">
    .right{
        height: 100px;
        display: flex;
        align-items: center;
        ul {
            display: flex;
            li{
                padding: 0 8px;
                font-size: 26px
            }
        }
    }
</style>
