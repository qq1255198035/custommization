<template>
      <div id="Footer">
            <p>
                  © 2019 Westacks Ltd. All Rights Reserved
            </p>
      </div>      
</template>
<script>
export default {
      
}
</script>
<style lang="less" scoped>
      #Footer{
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            p{
                  text-align: center;
                  padding: 30px 0;
                  color: rgba(255, 255, 255, 0.5)
            }
      }
</style>
