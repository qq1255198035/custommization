<template>
  <div id="doct2">
    <a-icon type="check" />
  </div>
</template>
<style lang="less" scoped>
#doct2 {
  width: 26px;
  height: 26px;
  background-color: #fff;
  border-radius: 13px;
  display: flex;
  align-items: center;
  justify-items: center;
  text-align: center;
  padding-left: 5px;
  margin-top: 10px;
  i {
    color: #33b8b3;
  }
}
@media screen and (max-width: 768px) and (min-width: 325px){
  #doct2{
    i{
      font-size: 10px;
    }
  }
}
</style>
