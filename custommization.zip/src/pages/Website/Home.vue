<template>
    <div id="home">
        <div class="homeBanner">
                <img src="@/assets/banner.png">
                <commonBtn
                    @gotoLogin="$router.push({path: '/login'})"
                    :width="'162px'"
                    :padding="'15px'"
                    :radio="'22px'"
                    :fontsize="'16px'"
                    :title="'Customize now'"
                />
        </div>
        <div class="whatTCK">
                <h3 class="homeTitle01">What’s Custom King?</h3>
                <h2 class="homeTitle02 wb_60">100% Customization</h2>
                <p class="homeCon01 wb_70">Custom King is a platform that allows users to create and share their custom designed apparels online. Our team consists of designers and artists that enjoys bringing creative ideas to life.</p>
                <a-row>
                    <a-col :span="6" class="whatIcon">
                        <h5><i class="titleIcon iconfont icon-Orders"></i></h5>
                        <h4>Group Orders</h4>
                        <a-row class="whatTxt wb_70">
                            <a-col :span="3"><i class="iconfont icon-duihao"></i></a-col>
                            <a-col :span="21">group orders seamlessly</a-col>
                        </a-row>
                        <a-row class="whatTxt wb_70">
                            <a-col :span="3"><i class="iconfont icon-duihao"></i></a-col>
                            <a-col :span="21">Supports individual payments</a-col>
                        </a-row>
                    </a-col>
                    <a-col :span="6" class="whatIcon">
                        <h5><i class="titleIcon iconfont icon-Sharable"></i></h5>
                        <h4>Sharable Links</h4>
                        <a-row class="whatTxt wb_70">
                            <a-col :span="3"><i class="iconfont icon-duihao"></i></a-col>
                            <a-col :span="21">Easy, sharable links</a-col>
                        </a-row>
                        <a-row class="whatTxt wb_70">
                            <a-col :span="3"><i class="iconfont icon-duihao"></i></a-col>
                            <a-col :span="21">Buyers can pick sizes, quantity and check-out</a-col>
                        </a-row>
                    </a-col>
                    <a-col :span="6" class="whatIcon">
                        <h5><i class="titleIcon iconfont icon-Custom"></i></h5>
                        <h4>Custom Artworks</h4>
                        <a-row class="whatTxt wb_70">
                            <a-col :span="3"><i class="iconfont icon-duihao"></i></a-col>
                            <a-col :span="21">Online design using our tools or upload you art</a-col>
                        </a-row>
                        <a-row class="whatTxt wb_70">
                            <a-col :span="3"><i class="iconfont icon-duihao"></i></a-col>
                            <a-col :span="21">On demand mockups also available for 100% customized designs</a-col>
                        </a-row>
                    </a-col>
                    <a-col :span="6" class="whatIcon">
                        <h5><i class="titleIcon iconfont icon-Instant"></i></h5>
                        <h4>Instant Quotes</h4>
                        <a-row class="whatTxt wb_70">
                            <a-col :span="3"><i class="iconfont icon-duihao"></i></a-col>
                            <a-col :span="21">Hassle-free, online quotations for custom designs</a-col>
                        </a-row>
                        <a-row class="whatTxt wb_70">
                            <a-col :span="3"><i class="iconfont icon-duihao"></i></a-col>
                            <a-col :span="21">Easy to use system for distributors</a-col>
                        </a-row>
                    </a-col>
                </a-row>            
        </div>
        <!-- //什么是CUSTOM KING -->
        <!-- 我们的产品 -->
        <div class="ourProducts" id="components-anchor">
            <h3 class="homeTitle01">Our Products</h3>
            <h2 class="homeTitle02 wb_60">From custom teamwear to corporate uniforms, we got them all!</h2>
            <p class="homeCon01 wb_70">Select from our catalog or our dedicated designers can help you to create the perfect apparel for you!</p>
            <div class="productsImg wb_90">
            <a-row>
                <a-col :span="8">
                    <div class="box_1">
                        <div class="mar_bor"></div>
                        <!--正面-->
                        <div class="info">
                            <div class="sm_img"></div>
                        </div>
                        <!--反面-->
                        <div class="ingo_fm">
                            <h3>sports</h3>
                            <h4>Basketball Shirt</h4>
                        </div>
                    </div>
                </a-col>
                <a-col :span="8">
                    <div class="box_1">
                        <div class="mar_bor"></div>
                        <!--正面-->
                        <div class="info1 info">
                            <div class="sm_img"></div>
                        </div>
                        <!--反面-->
                        <div class="ingo_fm">
                            <h3>sports</h3>
                            <h4>Basketball Shirt</h4>
                        </div>
                    </div>
                </a-col>
                <a-col :span="8">
                    <div class="box_1">
                        <div class="mar_bor"></div>
                        <!--正面-->
                        <div class="info2 info">
                            <div class="sm_img"></div>
                        </div>
                        <!--反面-->
                        <div class="ingo_fm">
                            <h3>sports</h3>
                            <h4>Basketball Shirt</h4>
                        </div>
                    </div>
                </a-col>
            </a-row>
            <a-row>
                <a-col :span="8">
                    <div class="box_1">
                        <div class="mar_bor"></div>
                        <!--正面-->
                        <div class="info3 info">
                            <div class="sm_img"></div>
                        </div>
                        <!--反面-->
                        <div class="ingo_fm">
                            <h3>sports</h3>
                            <h4>Basketball Shirt</h4>
                        </div>
                    </div>
                </a-col>
                <a-col :span="8">
                    <div class="box_1">
                        <div class="mar_bor"></div>
                        <!--正面-->
                        <div class="info info4">
                            <div class="sm_img"></div>
                        </div>
                        <!--反面-->
                        <div class="ingo_fm">
                            <h3>sports</h3>
                            <h4>Basketball Shirt</h4>
                        </div>
                    </div>
                </a-col>
                <a-col :span="8">
                    <div class="box_1">
                        <div class="mar_bor"></div>
                        <!--正面-->
                        <div class="info info5">
                            <div class="sm_img"></div>
                        </div>
                        <!--反面-->
                        <div class="ingo_fm">
                            <h3>sports</h3>
                            <h4>Basketball Shirt</h4>
                        </div>
                    </div>
                </a-col>
            </a-row>
            </div>
        </div>
        <!-- //我们的产品 -->
        <!-- 我们的品牌 -->
        <div class="ourBrands">
            <h3 class="homeTitle01">Our Brands</h3>
            <h2 class="homeTitle02 wb_60">Create your own classic</h2>
            <p class="homeCon01 wb_70">Custom King is a platform that allows users to create and share their custom designed apparels online. Our team consists of designers and artists that enjoys bringing creative ideas to life</p>
            <div class="main1140">
                    <!--品牌-->
                <div class="process-box">
                    <ul class="one">
                        <li>
                            <div class="kuang kuang1"></div>
                            <div class="kuang kuang2"></div>
                        </li>
                        <li class="pr_ml">
                            <div class="kuang kuang1"></div>
                            <div class="kuang kuang2"></div>
                            <div class="text1">
                            <div class="bg bg1"></div>
                            </div>
                            <div class="text2">
                                <div class="mengban"></div>
                                <p class="desc">YS</p>
                            </div>
                        </li>
                        <li>
                            <div class="kuang kuang1"></div>
                            <div class="kuang kuang2"></div>
                            <div class="text1">
                                    <div class="bg bg3"></div>
                            </div>
                            <div class="text2">
                                    <div class="mengban"></div>
                                    <p class="desc">Champion</p>
                            </div>
                        </li>
                        <li>
                            <div class="kuang kuang1"></div>
                            <div class="kuang kuang2"></div>
                            <div class="text1">
                                <div class="bg bg6" style="font-size: 25px; text-shadow: grey 3px 3px 2px; color:#fff;display:flex;flex-direction: column;justify-content:center;align-items:center;">
                                    COMING
                                    <span style="margin-top: -10px;">SOON</span>
                                </div>
                            </div>
                            <div class="text2">
                                <div class="mengban"></div>
                                <p class="desc">COMING SOON</p>
                            </div>
                        </li>
                        
                        <li class="pr_ml">
                            <div class="kuang kuang1"></div>
                            <div class="kuang kuang2"></div>
                        </li>
                    </ul>
                    <ul class="two">
                        <li>
                            <div class="kuang kuang1"></div>
                            <div class="kuang kuang2"></div>
                            <div class="text1">
                                <div class="bg bg5" style="font-size: 25px; text-shadow: grey 3px 3px 2px; color:#fff;display:flex;flex-direction: column;justify-content:center;align-items:center;">
                                    COMING
                                    <span style="margin-top: -10px;">SOON</span>
                                </div>
                            </div>
                            <div class="text2">
                                <div class="mengban"></div>
                                <p class="desc">COMING SOON</p>
                            </div>
                        </li>
                        <li>
                            <div class="kuang kuang1"></div>
                            <div class="kuang kuang2"></div>
                            <div class="text1">
                                    <div class="bg bg4"></div>
                            </div>
                            <div class="text2">
                                    <div class="mengban"></div>
                                    <p class="desc">Newline</p>
                            </div>
                        </li>
                        <li>
                            <div class="kuang kuang1"></div>
                            <div class="kuang kuang2"></div>
                            <div class="text1">
                                <div class="bg bg2"></div>
                            </div>
                            <div class="text2">
                                <div class="mengban"></div>
                                <p class="desc">DJH</p>
                            </div>
                        </li>
                        
                        <li>
                            <div class="kuang kuang1"></div>
                            <div class="kuang kuang2"></div>
                            <div class="text1">
                                <div class="bg bg7" style="font-size: 25px; text-shadow: grey 3px 3px 2px; color:#fff;display:flex;flex-direction: column;justify-content:center;align-items:center;">
                                    COMING
                                    <span style="margin-top: -10px;">SOON</span>
                                </div>
                            </div>
                            <div class="text2">
                                <div class="mengban"></div>
                                <p class="desc" >COMING SOON</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <!--品牌-->
            </div>
        </div>
        <!-- //我们的品牌 -->
        <!-- 加入我们 -->
        <!-- <div class="purchaseNow">
            <a-row>
                <a-col :span="10" class="purchaseText">To start your project with us</a-col>
                <a-col :span="14" class="purchaseBtn txtRight"><router-link to="/login">Purchase Now</router-link></a-col>
            </a-row>
        </div> -->
        <!-- //加入我们 -->
        <!-- TCK -->
        <div class="tck wb_70">
            <a-row>            
                <a-col :span="8" class="tckLeft">
                    <h2><img src="@/assets/LogoGray.png"></h2>
                    <div class="homeVideo wb_80">
                        <video ></video>
                    </div>
                    <p class="wb_80">Want the latest promotions and updates? Subscribe to our mailing list!</p>
                    <input type="text" class="tckInput wb_80 mb_20" value="Your E-maill" onfocus="javascript:if(this.value=='Your E-maill')this.value='';" v-model="email">
                    <p class="wb_80"><a @click="handleSubmit">Subscribe</a></p>
                </a-col>
                <a-col :span="8" class="tckCenter">
                    <h3>QUICK LINK</h3>
                    <router-link to="/home">Home</router-link>
                    <a href="#components-anchor">Products</a>
                    <router-link to="/register">Become A Seller</router-link>
                    <router-link to="/about">About Us</router-link>
                </a-col>
                <a-col :span="8" class="tckRight">                
                        <h3>CONTACT</h3>
                        <div class="contactCon mb_20">
                            <h4>Phone</h4>
                            <ul>
                                <li>(647) 983-8195</li>
                            </ul>
                        </div>
                        <div class="contactCon mb_20">
                            <h4>Email</h4>
                            <ul>
                                <li>info@thecustomking.ca</li>
                                <li>THECUSTOMKING@gmail.com</li>
                            </ul>
                        </div>
                        <div class="contactCon">
                            <h4>Address</h4>
                            <p>5005 Steeles Ave E, Unit 105 Scarborough, Ontario M1V 5K1 Canada</p>
                        </div>
                </a-col>
            </a-row>
        </div>
        <!-- //TCK -->
        <!-- 版权所有 -->
        <div class="copyright">
            <a-row>
                <a-col :span="12">
                    <a href=""><i class="iconfont icon-fb"></i></a>
                    <a href=""><i class="iconfont icon-wh"></i></a>
                    <a href=""><i class="iconfont icon-sina"></i></a>
                </a-col>
                <a-col :span="12" class="copyText txtRight">
                    Copyright ◎ Concord 2019.All Right Reserved
                </a-col>
            </a-row>
        </div>
    </div> 
</template>
<script>
import commonBtn from "@/components/commonBtn/commonBtn"
import {
    axios
} from '@/utils/request'
export default {
    components:{
        commonBtn
    },
    data () {
        return {
            email: ''
        }
    },
    methods:{
        handleSubmit(){
            if(this.email){
                let reg = new RegExp("^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$");
                if(reg.test(this.email)){
                    axios({
                        url: 're.php?mail=' + this.email+ '&' + window.location.search,
                        method: 'get'
                        // eslint-disable-next-line
                    }).then(res => {
                        this.modelShow = true
                    })
                }else{
                    alert('The Email format is wrong!')
                }
            }else{
                    alert('Please fill in the Email!')
            }
        }
    }
}
</script>
<style lang="less">
@import url('./../../assets/iconfont/iconfont.css');
@import url('./../../assets/iconfont02/iconfont.css');
#home{
    background-color: #fff;
}
</style>